# Meta llama2 70b chat LLM 
* Experience the power of llma2 70b chat model created by meta.
To acess it [Here](https://wambugukinyuai.streamlit.app/).
> - Hugging face made this possible.
## Libraries used
> 1. Hugchat install by:
``` Bash
pip install hugchat
```
### Other libraries used:
``` Bash 
pip install streamlit 
```
- The hug chat library is used as unofficial made API to access `hugging face`. It uses authentication ie your `email adresss` & `password`.

- We made use of  streamlit to host the chat interface, which appears cool.

- Meta llma2 is free and open source.
#### What can llama2 do:
- [x] Answer questions of any form. 
- [x] Coding.
- [x] Commercials use.
 - [x] Creativity in things like advertisements, post.
- [x]  Able to reject offensive prompt.
- [x] Has memory you can chat with as you would with human.
- [ ] It is free.

__Note:__ The web app is still in development it might break, still in for testing.
