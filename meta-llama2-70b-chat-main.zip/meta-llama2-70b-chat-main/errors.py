class LoginError(Exception):
    pass
    